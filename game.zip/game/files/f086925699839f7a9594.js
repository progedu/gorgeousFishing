function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ActionType = void 0;
      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType = exports.ActionType || (exports.ActionType = {}));
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Easing = void 0;
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
        /**
         * 入力値を easeInOutBack した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutBack(t, b, c, d) {
          var x = t / d;
          var c1 = 1.70158;
          var c2 = c1 * 1.525;
          var v = x < 0.5 ? Math.pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2) / 2 : (Math.pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
          return b + c * v;
        }

        Easing.easeInOutBack = easeInOutBack;
        /**
         * 入力値を easeOutBounce した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutBounce(t, b, c, d) {
          var x = t / d;
          var n1 = 7.5625;
          var d1 = 2.75;
          var v;

          if (x < 1 / d1) {
            v = n1 * x * x;
          } else if (x < 2 / d1) {
            v = n1 * (x -= 1.5 / d1) * x + 0.75;
          } else if (x < 2.5 / d1) {
            v = n1 * (x -= 2.25 / d1) * x + 0.9375;
          } else {
            v = n1 * (x -= 2.625 / d1) * x + 0.984375;
          }

          return b + c * v;
        }

        Easing.easeOutBounce = easeOutBounce;
      })(Easing = exports.Easing || (exports.Easing = {}));
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = void 0;

      var Tween_1 = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween_1.Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */


        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (!revert) {
            this.clear();
            return;
          }

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.cancel(true);
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      exports.Timeline = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Tween = void 0;

      var ActionType_1 = require("./ActionType");

      var Easing_1 = require("./Easing");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType_1.ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType_1.ActionType.TweenByMult : ActionType_1.ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType_1.ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType_1.ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType_1.ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType_1.ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */


        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];

              if (!action.initialized) {
                this._initAction(action);
              }

              var keys = Object.keys(action.goal);

              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }

              if (action.type === ActionType_1.ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType_1.ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType_1.ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (revert) {
            var keys = Object.keys(this._initialProp);

            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType_1.ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType_1.ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType_1.ActionType.TweenTo:
              case ActionType_1.ActionType.TweenBy:
              case ActionType_1.ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j]; // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)

                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType_1.ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType_1.ActionType.TweenTo && action.type !== ActionType_1.ActionType.TweenBy && action.type !== ActionType_1.ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType_1.ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      exports.Tween = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Timeline_1 = require("./Timeline");

      Object.defineProperty(exports, "Timeline", {
        enumerable: true,
        get: function get() {
          return Timeline_1.Timeline;
        }
      });

      var Tween_1 = require("./Tween");

      Object.defineProperty(exports, "Tween", {
        enumerable: true,
        get: function get() {
          return Tween_1.Tween;
        }
      });

      var Easing_1 = require("./Easing");

      Object.defineProperty(exports, "Easing", {
        enumerable: true,
        get: function get() {
          return Easing_1.Easing;
        }
      });
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.AStage = void 0;

      var AStage =
      /** @class */
      function () {
        function AStage() {
          this.finishCallback = [];
        }

        AStage.prototype.finishStage = function () {
          this.finishCallback.forEach(function (cb) {
            cb();
          });
        };

        return AStage;
      }();

      exports.AStage = AStage;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.AudioPresenter = void 0;

      var Global_1 = require("./Global");

      var AudioPresenter =
      /** @class */
      function () {
        function AudioPresenter(_scene) {
          this._s = null;
          this.bgmPlayer = null;
          this._s = _scene;
        }

        AudioPresenter.initialize = function (_s) {
          AudioPresenter.instance = new AudioPresenter(_s);
        };

        AudioPresenter.prototype.playBGM = function (name, volume) {
          if (volume === void 0) {
            volume = 0.5;
          }

          if (Global_1.Global.instance.muteSound) {
            return;
          }

          if (this.bgmPlayer !== null) {
            if (this.bgmPlayer.id === name) {
              return;
            } else {
              this.stopBGM();
            }
          }

          this.bgmPlayer = this._s.asset.getAudioById(name);
          this.bgmPlayer.play().changeVolume(volume);
        };

        AudioPresenter.prototype.playRandomBGM = function () {
          var bgms = ["bgm_dm", "bgm_gohands", "bgm_madarasukaru", "bgm_namaon", "bgm_sabaneko"];
          var index = Math.floor(bgms.length * Math.random());
          this.playBGM(bgms[index]);
        };

        AudioPresenter.prototype.stopBGM = function () {
          if (this.bgmPlayer === null) {
            return;
          }

          this.bgmPlayer.stop();
          this.bgmPlayer = null;
        };

        AudioPresenter.prototype.playSE = function (name, volume) {
          if (volume === void 0) {
            volume = 0.5;
          }

          if (Global_1.Global.instance.muteSound) {
            return;
          }

          this._s.asset.getAudioById(name).play().changeVolume(volume);
        };

        return AudioPresenter;
      }();

      exports.AudioPresenter = AudioPresenter;
    }, {
      "./Global": 13
    }],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FieldPopupLabel = void 0;

      var NumberValue_1 = require("./NumberValue");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var FieldPopupLabel =
      /** @class */
      function () {
        function FieldPopupLabel(_s, textColor) {
          this.rootEntity = new g.E({
            scene: _s,
            x: 0,
            y: 0
          });
          this.textColor = textColor;
        }

        Object.defineProperty(FieldPopupLabel.prototype, "value", {
          set: function set(_v) {
            this.label.text = _v.toString();

            if (_v > 0) {
              this.label.text = "+" + this.label.text;
            }

            this.label.invalidate();
            this.label.modified();
          },
          enumerable: false,
          configurable: true
        });

        FieldPopupLabel.prototype.init = function (_s) {
          var _f = NumberValue_1.NumberFont.instance;

          var _l = _f.genelateLabel28(_s, this.textColor);

          this.label = _l;
          this.font = _f;
          this.rootEntity.append(_l);
        };

        FieldPopupLabel.prototype.dispose = function () {
          if (this.label.destroyed()) {
            return;
          }

          this.label.destroy();
          this.font.destroy();
        };

        FieldPopupLabel.prototype.show = function (_s, sx, sy) {
          var tl = new akashic_timeline_1.Timeline(_s);
          tl.create(this.rootEntity).fadeIn(100, akashic_timeline_1.Easing.easeInQuad).moveTo(sx, sy - 10, 300).fadeOut(1500, akashic_timeline_1.Easing.easeOutQuad);
          this.rootEntity.x = sx;
          this.rootEntity.y = sy;
          this.rootEntity.modified();
        };

        return FieldPopupLabel;
      }();

      exports.FieldPopupLabel = FieldPopupLabel;
    }, {
      "./NumberValue": 14,
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FieldScene = void 0;

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var Global_1 = require("./Global");

      var AudioPresenter_1 = require("./AudioPresenter");

      var AStage_1 = require("./AStage");

      var OuterParamReceiver_1 = require("./OuterParamReceiver");

      var FishingRod_1 = require("./entity/FishingRod");

      var Sea_1 = require("./entity/Sea");

      var Resources_1 = require("./Resources");

      var constants_1 = require("./constants");

      var FieldScore_1 = require("./FieldScore");

      var GameTimer_1 = require("./GameTimer");

      var ReadyGo_1 = require("./ReadyGo");

      var TimeOver_1 = require("./TimeOver");

      var GameOver_1 = require("./GameOver");

      var FieldPopupLabel_1 = require("./FieldPopupLabel"); // ここで全リアクションのリストを定義


      var playerStatusMap = {
        "catch": {
          imageId: getRandomGozyasuAssetId(),
          voiceId: "revo",
          time: 2000
        },
        "zirai": {
          imageId: getRandomGozyasuAssetId(),
          voiceId: "mada",
          time: 2000
        }
      };

      var FieldScene =
      /** @class */
      function (_super) {
        __extends(FieldScene, _super);

        function FieldScene(_scene) {
          var _this = _super.call(this) || this;

          _this.isPlaying = false;
          /**
           * ドラゴンキューブ
           */

          _this.isDragoncube01Got = false;
          _this.isDragoncube02Got = false;
          _this.isDragoncube03Got = false;
          _this.score = 0;
          _this.readyGo = null;
          _this.scene = _scene;
          Resources_1.setResources({
            timeline: new akashic_timeline_1.Timeline(_scene),
            font: createFont()
          });
          return _this;
        }

        FieldScene.prototype.activate = function (_scene) {
          var _this = this;
          /**
           * 釣り部分を作成
           */


          this.root = new g.E({
            scene: _scene
          });
          this.scene.append(this.root); // アツマール環境の時だけ背景を出す

          if (Global_1.Global.instance.isAtsumaru) {
            createStage(this.root);
          }

          this.boatSprite = createBoatSprite(this.root);
          this.sea = createSea(this.root);
          this.fishingRod = createFishingRod(this.root);
          this.scene.onUpdate.add(function () {
            _this.step();
          });
          this.scene.onPointDownCapture.add(function () {
            _this.onPointDown();
          });
          /**
           * スコア部分を作成
           */

          var _sv = new FieldScore_1.FieldScore(_scene);

          _sv.init(_scene);

          this.scene.append(_sv.rootEntity);

          _sv.show(_scene, FieldScene.FIELDSCORE_POS_X, FieldScene.FIELDSCORE_POS_Y);

          _sv.value = this.score;
          this.scoreView = _sv;
          /**
           * タイマー部分を作成
           */

          var gt = Global_1.Global.instance.totalTimeLimit - FieldScene.TIMER_MERGIN;

          if (FieldScene.TIMER_MAX < gt) {
            gt = FieldScene.TIMER_MAX;
          }

          var t = new GameTimer_1.GameTimer(_scene);
          t.show(FieldScene.GAMETIMER_POS_X, FieldScene.GAMETIMER_POS_Y, gt);
          this.scene.append(t.rootEntity);
          this.timer = t;
          this.sea.setTimer(t);

          var _readygo = new ReadyGo_1.ReadyGo(_scene);

          this.readyGo = _readygo;
          this.scene.append(_readygo.rootEntity);

          _readygo.show().finishCallback.push(this.gameStartInit.bind(this));
        };

        FieldScene.prototype.gameStartInit = function () {
          var _this = this;

          var t = this.timer;
          this.start();
          t.start().finishCallback.push(function () {
            if (!Global_1.Global.instance.DEBUG) {
              var _eff = new TimeOver_1.TimeOver(_this.scene);

              _this.scene.append(_eff.rootEntity);

              _eff.show(250, 500).finishCallback.push(function () {
                _this.finish();
              });
            }
          });
          AudioPresenter_1.AudioPresenter.instance.playRandomBGM();
        };
        /**
         * ゲームを開始する
         */


        FieldScene.prototype.start = function () {
          this._startGame();
        };
        /**
         * ゲームを1フレーム進める
         */


        FieldScene.prototype.step = function () {
          if (!this.isPlaying) return;
          this.sea.checkFishOnHook(this.fishingRod);
        };
        /**
         * ゲーム終了
         */


        FieldScene.prototype.finish = function () {
          this.isPlaying = false;
          this.finishStage();
        };
        /**
         * タップしたときの処理
         */


        FieldScene.prototype.onPointDown = function () {
          var _this = this;

          if (!this.isPlaying) return;
          this.fishingRod.catchUp(function () {
            var pattern = _this.fishingRod.getFishingPattern(_this.sea.capturedFishList);

            var addScore = _this.calcScore(_this.sea.capturedFishList); // 時間が減る処理


            var changedTime = 0; // ドラゴンキューブ

            _this.sea.capturedFishList.forEach(function (fish) {
              if (fish.name == "ドラゴンキューブ01") {
                _this.isDragoncube01Got = true;
                displayDragonCube01(_this.root);
              }

              if (fish.name == "ドラゴンキューブ02") {
                _this.isDragoncube02Got = true;
                displayDragonCube02(_this.root);
              }

              if (fish.name == "ドラゴンキューブ03") {
                _this.isDragoncube03Got = true;
                displayDragonCube03(_this.root);
              }
            });

            if (_this.isDragoncube01Got && _this.isDragoncube02Got && _this.isDragoncube03Got) {
              addScore = 10000;
            }

            _this.sea.capturedFishList.forEach(function (fish) {
              if (fish.name == "宝箱") {
                // 釣り針を増やす
                _this.fishingRod.addHooks();
              }
            }); // スコア表示処理


            _this.addScore(addScore);

            _this.sea.capturedFishList.forEach(function (fish) {
              // 一番時間が減るものを優先する
              if (fish.time !== 0 && fish.time < changedTime) changedTime = fish.time;
            });

            _this.timer.changeTime(changedTime); // 時間に変更がある場合は減るもしくは増える時間の表示でそれ以外はスコア加算減算の表示


            var popupLabel, popupValue;

            if (changedTime !== 0 && changedTime > -99999) {
              popupLabel = new FieldPopupLabel_1.FieldPopupLabel(_this.scene, "red");
              popupValue = changedTime;
            } else if (addScore != 0) {
              popupLabel = new FieldPopupLabel_1.FieldPopupLabel(_this.scene);
              popupValue = addScore;
            }

            if (popupLabel) {
              popupLabel.init(_this.scene);

              _this.scene.append(popupLabel.rootEntity);

              popupLabel.value = popupValue;
              popupLabel.show(_this.scene, FieldScene.FIELD_POPUP_LABEL_POS_X, FieldScene.FIELD_POPUP_LABEL_POS_Y);
            } // ゲームオーバー判定


            var isGameOver = _this.sea.capturedFishList.filter(function (fish) {
              return fish.isGameOver;
            }).length > 0 ? true : false;

            if (isGameOver) {
              var gameOverEffect = new GameOver_1.GameOver(_this.scene);

              _this.scene.append(gameOverEffect.rootEntity);

              gameOverEffect.show(250, 500).finishCallback.push(function () {
                _this.finish();

                _this.timer.finishCallback.pop();

                _this.timer.destroy();
              });
            }

            _this.reflectStatus(_this.getStatus(_this.sea.capturedFishList, addScore));

            _this.fishingRod.fishing(pattern);

            _this.sea.destroyCapturedFish();
          });
        };
        /**
         * ゲーム本編開始
         */


        FieldScene.prototype._startGame = function () {
          this.isPlaying = true;
          this.sea.startFishTimer();
        };

        FieldScene.prototype.dispose = function () {
          if (this.scene.destroyed()) {
            return;
          }

          this.scene.remove(this.root);
          this.scene.remove(this.timer.rootEntity);
          this.scene.remove(this.scoreView.rootEntity);
        };
        /**
         * スコアをセットする
         */


        FieldScene.prototype.setScore = function (score) {
          score = Math.min(score, 99999);
          this.score = score;
          Global_1.Global.instance.score = score;
        };
        /**
         * スコアの加算
         */


        FieldScene.prototype.addScore = function (score) {
          var newScore = this.score + score; // スコアがマイナスになると結果発表ページがバグるのでマイナスにならないようにする

          if (newScore < 0) {
            newScore = 0;
          }

          this.setScore(newScore);
          this.scoreView.value = this.score;
          OuterParamReceiver_1.OuterParamReceiver.setGlobalScore(this.score);
        };
        /**
         * 釣った魚からスコアを計算
         */


        FieldScene.prototype.calcScore = function (capturedFishList) {
          return capturedFishList.reduce(function (score, fish) {
            return score += fish.score;
          }, 0);
        }; // リアクションリストのキーを返す。スコア等から取るべきリアクションを決める。


        FieldScene.prototype.getStatus = function (list, score) {
          return score >= 0 && list.length > 0 ? "catch" : null; // switch(fishingPattern) {
          // 	case "Stuck":
          // 		return "miss";
          // 	case "Default":
          // 		return score >= 10000 ? "big-catch" : null;
          // }
        }; // 釣った時のリアクション


        FieldScene.prototype.reflectStatus = function (status) {
          var _this = this;

          if (status === null || !playerStatusMap[status]) {
            return;
          } // その状態に合ったボイスを出す


          AudioPresenter_1.AudioPresenter.instance.playSE(playerStatusMap[status].voiceId);
          return; // 画像の大きさ合わせが難しいのでいったん音声だけ
          // その状態に合った画像を出す

          var assetId = playerStatusMap[status].imageId;
          var beforeSurface = this.boatSprite._surface;
          this.boatSprite._surface = g.SurfaceUtil.asSurface(this.scene.asset.getImageById(assetId));
          this.boatSprite.modified(); // 一定時間後に画像を戻す

          this.scene.setTimeout(function () {
            _this.boatSprite._surface = beforeSurface;

            _this.boatSprite.modified();
          }, playerStatusMap[status].time);
        };

        FieldScene.TIMER_MERGIN = 32;
        FieldScene.TIMER_MAX = 30;
        FieldScene.FIELDSCORE_POS_X = 552;
        FieldScene.FIELDSCORE_POS_Y = 0;
        FieldScene.FIELD_POPUP_LABEL_POS_X = 150;
        FieldScene.FIELD_POPUP_LABEL_POS_Y = 80;
        FieldScene.GAMETIMER_POS_X = 82;
        FieldScene.GAMETIMER_POS_Y = 4;
        return FieldScene;
      }(AStage_1.AStage);

      exports.FieldScene = FieldScene;
      /**
       * フォントを作成
       */

      function createFont() {
        return new g.DynamicFont({
          game: g.game,
          fontFamily: constants_1.FONT_FAMILY,
          size: constants_1.FONT_SIZE
        });
      }
      /**
       * 背景を作成
       */


      function createStage(parent) {
        var imageAsset = parent.scene.asset.getImageById("bg_space");
        new g.Sprite({
          scene: parent.scene,
          src: imageAsset,
          width: g.game.width,
          height: g.game.height,
          parent: parent
        });
      }
      /**
       * 舟のスプライトを作成
       */


      function createBoatSprite(parent) {
        var asset = parent.scene.asset.getImageById(getRandomGozyasuAssetId());
        var width = 160;
        return new g.Sprite({
          scene: parent.scene,
          src: asset,
          width: width,
          height: width * asset.height / asset.width,
          srcWidth: asset.width,
          srcHeight: asset.height,
          x: 0,
          y: 60,
          parent: parent
        });
      }

      function getRandomGozyasuAssetId() {
        var gozyasuList = ["gozyasu_dm", "gozyasu_masakichi", "gozyasu_muxutube_danball", "gozyasu_muxutube_rocket", "gozyasu_nyanu", "gozyasu_odu", "gozyasu_ringomarknoa", "gozyasu_shinkeya", "gozyasu_ss"];
        var index = Math.floor(gozyasuList.length * Math.random());
        return gozyasuList[index];
      }
      /**
       * 海を作成
       */


      function createSea(parent) {
        return new Sea_1.Sea({
          parent: parent
        });
      }
      /**
       * 釣竿を作成
       */


      function createFishingRod(parent) {
        var fishingRod = new FishingRod_1.FishingRod({
          parent: parent
        });
        return fishingRod;
      }

      function displayDragonCube01(parent) {
        var dragoncube01Asset = parent.scene.asset.getImageById("dragoncube01");
        var width = 30;
        new g.Sprite({
          scene: parent.scene,
          src: dragoncube01Asset,
          width: width,
          height: width * dragoncube01Asset.height / dragoncube01Asset.width,
          srcWidth: dragoncube01Asset.width,
          srcHeight: dragoncube01Asset.height,
          x: 200,
          y: 5,
          parent: parent
        });
      }

      function displayDragonCube02(parent) {
        var dragoncube02Asset = parent.scene.asset.getImageById("dragoncube02");
        var width = 30;
        new g.Sprite({
          scene: parent.scene,
          src: dragoncube02Asset,
          width: width,
          height: width * dragoncube02Asset.height / dragoncube02Asset.width,
          srcWidth: dragoncube02Asset.width,
          srcHeight: dragoncube02Asset.height,
          x: 250,
          y: 5,
          parent: parent
        });
      }

      function displayDragonCube03(parent) {
        var dragoncube03Asset = parent.scene.asset.getImageById("dragoncube03");
        var width = 30;
        new g.Sprite({
          scene: parent.scene,
          src: dragoncube03Asset,
          width: width,
          height: width * dragoncube03Asset.height / dragoncube03Asset.width,
          srcWidth: dragoncube03Asset.width,
          srcHeight: dragoncube03Asset.height,
          x: 300,
          y: 5,
          parent: parent
        });
      }
    }, {
      "./AStage": 6,
      "./AudioPresenter": 7,
      "./FieldPopupLabel": 8,
      "./FieldScore": 10,
      "./GameOver": 11,
      "./GameTimer": 12,
      "./Global": 13,
      "./OuterParamReceiver": 15,
      "./ReadyGo": 16,
      "./Resources": 17,
      "./TimeOver": 20,
      "./constants": 23,
      "./entity/FishingRod": 25,
      "./entity/Sea": 26,
      "@akashic-extension/akashic-timeline": 5
    }],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FieldScore = void 0;

      var NumberValue_1 = require("./NumberValue");

      var SpriteFactory_1 = require("./SpriteFactory");

      var FieldScore =
      /** @class */
      function () {
        function FieldScore(_s) {
          this.rootEntity = new g.E({
            scene: _s,
            x: 0,
            y: 0
          });
        }

        Object.defineProperty(FieldScore.prototype, "value", {
          set: function set(_v) {
            this.label.text = _v.toString();
            this.label.invalidate();
            var px = this.label.text.length * 28;
            this.label.x = this.pt.x - this.label.width;
            this.label.y = 5;
            this.label.modified();
          },
          enumerable: false,
          configurable: true
        });

        FieldScore.prototype.init = function (_s) {
          var _f = NumberValue_1.NumberFont.instance;

          var _l = _f.genelateLabel28(_s);

          this.label = _l;
          this.font = _f;

          var _pt = SpriteFactory_1.SpriteFactory.createPtImage(_s);

          _pt.x = -_pt.width;
          _pt.y = 10;

          _pt.modified();

          this.pt = _pt;
          this.rootEntity.append(_pt);
          this.rootEntity.append(_l);
        };

        FieldScore.prototype.dispose = function () {
          if (this.label.destroyed()) {
            return;
          }

          this.label.destroy();
          this.font.destroy();
          this.pt.destroy();
        };

        FieldScore.prototype.show = function (_s, sx, sy) {
          this.rootEntity.x = sx;
          this.rootEntity.y = sy;
          this.rootEntity.modified();
        };

        return FieldScore;
      }();

      exports.FieldScore = FieldScore;
    }, {
      "./NumberValue": 14,
      "./SpriteFactory": 19
    }],
    11: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.GameOver = void 0;

      var SpriteFactory_1 = require("./SpriteFactory");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var AudioPresenter_1 = require("./AudioPresenter");

      var GameOver =
      /** @class */
      function () {
        function GameOver(_s) {
          this.finishCallback = new Array();
          this._s = _s;
          this.rootEntity = new g.E({
            scene: _s
          });

          var _t = SpriteFactory_1.SpriteFactory.createGameOver(_s);

          _t.x = (_s.game.width - _t.width) / 2;
          _t.y = (_s.game.height - _t.height) / 2;

          _t.modified();

          _t.hide();

          this.gameOver = _t;
          this.rootEntity.append(_t);
        }

        GameOver.prototype.show = function (intime, wait) {
          var _this = this;

          var tt = new akashic_timeline_1.Timeline(this._s);
          AudioPresenter_1.AudioPresenter.instance.stopBGM();
          AudioPresenter_1.AudioPresenter.instance.playSE("se_explosion");
          var _tu = this.gameOver;

          _tu.scale(1.5);

          _tu.opacity = 0;

          _tu.modified();

          _tu.show();

          tt.create(this.gameOver, {
            modified: this.gameOver.modified,
            destroyed: this.gameOver.destroyed
          }).scaleTo(1, 1, intime).con().fadeIn(intime).wait(wait).every(function (e, p) {
            if (1 <= p) {
              tt.destroy();

              _this.finishCallback.forEach(function (c) {
                return c();
              });

              _tu.hide();
            }
          }, intime + wait);
          return this;
        };

        return GameOver;
      }();

      exports.GameOver = GameOver;
    }, {
      "./AudioPresenter": 7,
      "./SpriteFactory": 19,
      "@akashic-extension/akashic-timeline": 5
    }],
    12: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.GameTimer = void 0;

      var SpriteFactory_1 = require("./SpriteFactory");

      var NumberValue_1 = require("./NumberValue");

      var GameTimer =
      /** @class */
      function () {
        function GameTimer(_s) {
          this.finishCallback = [];
          this.pause = false;
          var ci = SpriteFactory_1.SpriteFactory.createClockIcon(_s);
          var nv = NumberValue_1.NumberFont.instance;
          var ti = nv.genelateLabel28(_s);
          var r = new g.E({
            scene: _s,
            x: 0,
            y: 0
          });
          r.append(ci);
          ti.x = ci.width;
          ti.y = 4;
          ti.modified();
          r.append(ti);
          r.hide();

          _s.append(r);

          this.clockIcon = ci;
          this.timer = ti;
          this.rootEntity = r;
          this._s = _s;
        }

        Object.defineProperty(GameTimer.prototype, "Pause", {
          get: function get() {
            return this.pause;
          },
          set: function set(v) {
            this.pause = v;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(GameTimer.prototype, "tv", {
          set: function set(value) {
            var v = value;

            if (GameTimer.DISPLAY_MAX < v) {
              v = GameTimer.DISPLAY_MAX;
            }

            this.timer.text = (v | 0).toString();
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(GameTimer.prototype, "now", {
          get: function get() {
            return this.timerValue | 0;
          },
          enumerable: false,
          configurable: true
        });

        GameTimer.prototype.destroy = function () {
          if (!this.clockIcon.destroyed()) {
            this.clockIcon.destroy();
          }
        };

        GameTimer.prototype.show = function (px, py, startSecond) {
          this.clockIcon.show();
          this.tv = startSecond;
          this.timer.invalidate();
          this.rootEntity.x = px;
          this.rootEntity.y = py;
          this.rootEntity.modified();
          this.rootEntity.show();
          this.timerValue = startSecond;
        };

        GameTimer.prototype.changeTime = function (diff) {
          var changed = this.timerValue + diff;

          if (changed < 0) {
            changed = 0;
          }

          this.tv = changed;
          this.timer.invalidate();
          this.timerValue = changed;
        };

        GameTimer.prototype.start = function () {
          var _this = this;

          var _s = this._s;

          if (this.timerEventIdentifier != null) {
            _s.clearInterval(this.timerEventIdentifier);
          }

          var ev = _s.setInterval(function () {
            if (_this.pause) {
              return;
            }

            _this.timerValue--;

            if (0 <= _this.timerValue) {
              _this.tv = _this.timerValue;
            }

            _this.timer.invalidate();

            if (_this.timerValue < 0) {
              if (_this.timerEventIdentifier != null) {
                _s.clearInterval(_this.timerEventIdentifier);
              }

              _this.finishCallback.forEach(function (e) {
                return e();
              });
            }
          }, 1000, this);

          this.timerEventIdentifier = ev;
          return this;
        };

        GameTimer.DISPLAY_MAX = 99;
        return GameTimer;
      }();

      exports.GameTimer = GameTimer;
    }, {
      "./NumberValue": 14,
      "./SpriteFactory": 19
    }],
    13: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Global = void 0;

      var Global =
      /** @class */
      function () {
        function Global() {
          this.score = 0;
          this.totalTimeLimit = 62;
          this.muteSound = false;
          this.difficulty = 1;
          this.random = g.game.random;
          this.DEBUG = false;
          this.isAtsumaru = false;
        }

        Global.init = function () {
          Global.instance = new Global();
        };

        Global.prototype.log = function (l) {
          if (this.DEBUG) {
            console.log(l);
          }
        };

        return Global;
      }();

      exports.Global = Global;
    }, {}],
    14: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.NumberFont = exports.NumberFontData = exports.NumberType = void 0;

      var Util_1 = require("./Util");

      var NumberType;

      (function (NumberType) {
        NumberType[NumberType["W28"] = 0] = "W28";
        NumberType[NumberType["W72"] = 1] = "W72";
        NumberType[NumberType["Y28"] = 2] = "Y28";
        NumberType[NumberType["R28"] = 3] = "R28";
      })(NumberType = exports.NumberType || (exports.NumberType = {}));

      var FontInfo =
      /** @class */
      function () {
        function FontInfo() {
          this.glyphWidth = 0;
          this.glyphHeight = 0;
          this.map = "";
        }

        return FontInfo;
      }();

      var NumberFontData =
      /** @class */
      function () {
        function NumberFontData(f, l) {
          this.label = null;
          this.font = null;
          this.label = l;
          this.font = f;
        }

        NumberFontData.prototype.destroy = function () {
          if (!this.label.destroyed()) {
            this.label.destroy();
          }

          if (!this.font.destroyed()) {
            this.font.destroy();
          }
        };

        return NumberFontData;
      }();

      exports.NumberFontData = NumberFontData;

      var NumberFont =
      /** @class */
      function () {
        function NumberFont() {}

        NumberFont.generate = function (s, type) {
          var fi = NumberFont.fontInfo[type];
          var imageAsset = s.asset.getImageById(NumberFont.IMAGE_NAME);
          var f = new g.BitmapFont({
            src: imageAsset,
            map: Util_1.Util.readJSON(s, fi.map),
            defaultGlyphWidth: fi.glyphWidth,
            defaultGlyphHeight: fi.glyphHeight
          });
          var l = new g.Label({
            scene: s,
            font: f,
            text: "",
            fontSize: fi.glyphWidth
          });
          return new NumberFontData(f, l);
        };

        Object.defineProperty(NumberFont, "instance", {
          get: function get() {
            if (NumberFont._instance == null) {
              NumberFont._instance = new NumberFont();
            }

            return NumberFont._instance;
          },
          enumerable: false,
          configurable: true
        });

        NumberFont.prototype.initialize = function (_s) {
          var imageAsset = _s.asset.getImageById(NumberFont.IMAGE_NAME);

          this.font28 = new g.BitmapFont({
            src: imageAsset,
            map: Util_1.Util.readJSON(_s, "glyph28"),
            defaultGlyphWidth: 28,
            defaultGlyphHeight: 32
          });
          this.font72 = new g.BitmapFont({
            src: imageAsset,
            map: Util_1.Util.readJSON(_s, "glyph72"),
            defaultGlyphWidth: 72,
            defaultGlyphHeight: 82
          });
        };

        NumberFont.prototype.genelateLabel28 = function (_s, textColor) {
          var label = new g.Label({
            scene: _s,
            font: this.font28,
            text: "",
            fontSize: 28
          });

          if (textColor) {
            label.textColor = textColor;
          }

          return label;
        };

        NumberFont.prototype.genelateLabel72 = function (_s) {
          return new g.Label({
            scene: _s,
            font: this.font72,
            text: "",
            fontSize: 72
          });
        };

        NumberFont.prototype.destroy = function () {
          if (!this.font28.destroyed()) {
            this.font28.destroy();
          }

          if (!this.font72.destroyed()) {
            this.font72.destroy();
          }
        };

        NumberFont.IMAGE_NAME = "ui_common";
        NumberFont._instance = null;
        NumberFont.fontInfo = [// w28
        {
          glyphWidth: 28,
          glyphHeight: 32,
          map: "glyph28"
        }, {
          glyphWidth: 72,
          glyphHeight: 82,
          map: "glyph72"
        }, {
          glyphWidth: 32,
          glyphHeight: 36,
          map: "glyph32_yellow"
        }];
        return NumberFont;
      }();

      exports.NumberFont = NumberFont;
    }, {
      "./Util": 22
    }],
    15: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.OuterParamReceiver = void 0;

      var Global_1 = require("./Global");

      var OuterParamReceiver =
      /** @class */
      function () {
        function OuterParamReceiver() {}

        OuterParamReceiver.receiveParamFromMessage = function (s) {
          s.message.add(function (msg) {
            if (msg.data && msg.data.type === "start") {
              if (msg.data.parameters) {
                if (msg.data.parameters.totalTimeLimit) {
                  Global_1.Global.instance.totalTimeLimit = msg.data.parameters.totalTimeLimit;
                }

                if (msg.data.parameters.difficulty) {
                  Global_1.Global.instance.difficulty = msg.data.parameters.difficulty;
                }

                if (msg.data.parameters.randomSeed) {
                  Global_1.Global.instance.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
                }
              }
            }
          });
        };

        OuterParamReceiver.paramSetting = function () {
          g.game.vars.gameState = {
            score: 0,
            playThreshold: 1,
            clearThreshold: 0
          };
        };

        OuterParamReceiver.setGlobalScore = function (score) {
          if (g.game.vars.gameState) {
            if (g.game.vars.gameState.score !== undefined) {
              g.game.vars.gameState.score = score;
            }
          }
        };

        OuterParamReceiver.setClearThreashold = function (v) {
          if (g.game.vars.gameState) {
            if (g.game.vars.gameState.clearThreshold !== undefined) {
              g.game.vars.gameState.clearThreshold = v;
            }
          }
        };

        return OuterParamReceiver;
      }();

      exports.OuterParamReceiver = OuterParamReceiver;
    }, {
      "./Global": 13
    }],
    16: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ReadyGo = void 0;

      var SpriteFactory_1 = require("./SpriteFactory");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var AudioPresenter_1 = require("./AudioPresenter");

      var ReadyGo =
      /** @class */
      function () {
        function ReadyGo(scene) {
          this.finishCallback = new Array();
          this.rootEntity = new g.E({
            scene: scene
          });
          this._s = scene;

          var _r = SpriteFactory_1.SpriteFactory.createReady(this._s);

          _r.x = (scene.game.width - _r.width) / 2;
          _r.y = (scene.game.height - _r.height) / 2;

          _r.modified();

          _r.hide();

          var _g = SpriteFactory_1.SpriteFactory.createStart(this._s);

          _g.x = (scene.game.width - _g.width) / 2;
          _g.y = (scene.game.height - _g.height) / 2;

          _g.modified();

          _g.hide();

          this.rootEntity.append(_r);
          this.rootEntity.append(_g);
          this.ready = _r;
          this.go = _g;
        }

        ReadyGo.prototype.show = function () {
          var _this = this;

          AudioPresenter_1.AudioPresenter.instance.playSE("estar");
          this.ready.show();
          this.fadeAction(this._s, this.ready, 500, 250, function () {
            _this.go.show();

            _this.fadeAction(_this._s, _this.go, 500, 250, function () {
              _this.finishCallback.forEach(function (x) {
                return x();
              });
            });
          });
          return this;
        };

        ReadyGo.prototype.fadeAction = function (_s, _es, delay, stop, cb) {
          var _this = this;

          var tt = new akashic_timeline_1.Timeline(this._s);

          var _hdelay = delay / 2;

          _es.scale(0);

          _es.modified();

          if (0 < stop) {
            tt.create(_es, {
              modified: _es.modified,
              destroyed: _es.destroyed
            }).scaleTo(1, 1, _hdelay).wait(stop).fadeOut(_hdelay, akashic_timeline_1.Easing.easeOutQuad).con().scaleTo(1.5, 1.5, _hdelay).every(function (e, p) {
              if (p <= 1) {
                if (cb != null) {
                  cb.bind(_this)();
                }

                if (!tt.destroyed()) {
                  tt.destroy(); // 呼べる？
                }
              }
            }, delay + stop);
          } else {
            tt.create(_es, {
              modified: _es.modified,
              destroyed: _es.destroyed
            }).scaleTo(1, 1, _hdelay).fadeOut(_hdelay, akashic_timeline_1.Easing.easeOutQuad).con().scaleTo(1.5, 1.5, _hdelay).every(function (e, p) {
              if (p <= 1) {
                if (cb != null) {
                  cb.bind(_this)();
                }

                tt.destroy(); // 呼べる？
              }
            }, delay + stop);
          }
        };

        ReadyGo.prototype.fadeInAction = function (_s, _es, delay, cb) {
          var _this = this;

          var tt = new akashic_timeline_1.Timeline(this._s);
          tt.create(_es, {
            modified: _es.modified,
            destroyed: _es.destroyed
          }).fadeOut(delay, akashic_timeline_1.Easing.easeOutQuad).every(function (e, p) {
            if (1 <= p) {
              if (cb != null) {
                cb.bind(_this)();
              }
            }
          }, delay);
        };

        ReadyGo.prototype.fadeOutAction = function (_s, _es, delay, cb) {
          var _this = this;

          var tt = new akashic_timeline_1.Timeline(this._s);
          tt.create(_es, {
            modified: _es.modified,
            destroyed: _es.destroyed
          }).fadeOut(delay, akashic_timeline_1.Easing.easeOutQuad).every(function (e, p) {
            if (p <= 1) {
              if (cb != null) {
                cb.bind(_this)();
              }
            }
          }, delay);
        };

        ReadyGo.prototype.destroy = function () {
          var arr = [this.ready, this.go, this.rootEntity];
          arr.forEach(function (x) {
            if (!x.destroyed()) {
              x.destroy();
            }
          });
        };

        return ReadyGo;
      }();

      exports.ReadyGo = ReadyGo;
    }, {
      "./AudioPresenter": 7,
      "./SpriteFactory": 19,
      "@akashic-extension/akashic-timeline": 5
    }],
    17: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.setResources = exports.getResources = void 0;

      function getResources() {
        return g.game.vars.resouces;
      }

      exports.getResources = getResources;

      function setResources(resouces) {
        g.game.vars.resouces = resouces;
      }

      exports.setResources = setResources;
    }, {}],
    18: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ResultScene = void 0;

      var SpriteFactory_1 = require("./SpriteFactory");

      var NumberValue_1 = require("./NumberValue");

      var Global_1 = require("./Global");

      var AudioPresenter_1 = require("./AudioPresenter");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var AStage_1 = require("./AStage");

      var OuterParamReceiver_1 = require("./OuterParamReceiver");

      var ResultScene =
      /** @class */
      function (_super) {
        __extends(ResultScene, _super);

        function ResultScene(scene) {
          var _this = _super.call(this) || this;

          _this.scoreValue = 12;
          _this.scene = scene;
          return _this;
        }

        Object.defineProperty(ResultScene.prototype, "val", {
          set: function set(v) {
            var _l = this.text;

            if (_l != null) {
              _l.text = v.toString();

              _l.invalidate();

              _l.x = 404 + 72 - _l.width;
              _l.y = 162;

              _l.modified();
            }
          },
          enumerable: false,
          configurable: true
        });

        ResultScene.prototype.activate = function (scene) {
          var _this = this; // アツマール環境の時だけ背景を設定


          if (Global_1.Global.instance.isAtsumaru) {
            var bg = new g.FilledRect({
              scene: scene,
              width: scene.game.width,
              height: scene.game.height,
              cssColor: "#FFFFFF"
            });
            scene.append(bg);
            var imageAsset = scene.asset.getImageById("bg_space");
            var bg2 = new g.Sprite({
              scene: scene,
              src: imageAsset,
              width: g.game.width,
              height: g.game.height
            });
            scene.append(bg2);
          }

          AudioPresenter_1.AudioPresenter.instance.stopBGM();
          var r = new g.E({
            scene: scene,
            width: scene.game.width,
            height: scene.game.height
          });
          OuterParamReceiver_1.OuterParamReceiver.setClearThreashold(1);
          var s = SpriteFactory_1.SpriteFactory.createSCOREFrame(scene);
          s.touchable = true;
          s.x = (scene.game.width - s.width) / 2;
          s.y = (scene.game.height - s.height) / 2;
          s.modified();
          var l = this.createScoreText(scene);
          r.append(s);
          r.append(l);
          l.text = Global_1.Global.instance.score.toString();
          l.invalidate();
          l.x = 404 + 72 - l.width;
          l.y = 162;
          l.modified();
          this.text = l;
          this.val = this.scoreValue = Global_1.Global.instance.score;

          var _tl = new akashic_timeline_1.Timeline(scene);

          _tl.create(l, {
            modified: l.modified,
            destroyed: l.destroyed
          }).every(function (e, p) {
            if (1 <= p) {
              _tl.destroy();

              _this.val = Global_1.Global.instance.score;
              return;
            }

            var _min = Math.pow(10, _this.text.text.length - 1); // **は べき乗との事


            var _max = Math.pow(10, _this.text.text.length) - 1;

            var _v = Global_1.Global.instance.random.get(_min, _max);

            _this.val = _v | 0;
          }, 1500);

          r.onPointUp.add(function () {
            _this.finishStage();
          }, this);
          this.frame = s;
          scene.append(r);
          this.scene = scene;
          this.root = r;
          AudioPresenter_1.AudioPresenter.instance.playSE("jin_000");
        };

        ResultScene.prototype.dispose = function () {
          if (this.frame.destroyed()) {
            return;
          }

          this.frame.destroy();
          this.root.destroy();
        };

        ResultScene.prototype.createScoreText = function (_s) {
          var nv = NumberValue_1.NumberFont.instance;
          return nv.genelateLabel72(_s);
        };

        return ResultScene;
      }(AStage_1.AStage);

      exports.ResultScene = ResultScene;
    }, {
      "./AStage": 6,
      "./AudioPresenter": 7,
      "./Global": 13,
      "./NumberValue": 14,
      "./OuterParamReceiver": 15,
      "./SpriteFactory": 19,
      "@akashic-extension/akashic-timeline": 5
    }],
    19: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.SpriteFactory = void 0;

      var SpriteFactory =
      /** @class */
      function () {
        function SpriteFactory() {}

        SpriteFactory.createTitle = function (_scene) {
          return SpriteFactory.createSpriteCore(_scene, "ui", 1, 289, 321, 519);
        };

        SpriteFactory.createManual = function (_scene) {
          return SpriteFactory.createSpriteCore(_scene, "ui", 1, 614, 453, 866);
        };

        SpriteFactory.createPictureFrame = function (_s) {
          return SpriteFactory.createSpriteCore(_s, "ui", 2, 2, 288, 288);
        };

        SpriteFactory.createRemainPieceFrame = function (s) {
          return SpriteFactory.createSpriteCore(s, "ui", 289, 1, 489, 65);
        };

        SpriteFactory.createSelectFrameL = function (s) {
          return SpriteFactory.createSpriteCore(s, "ui", 289, 66, 487, 264);
        };

        SpriteFactory.createSelectFrameM = function (s) {
          return SpriteFactory.createSpriteCore(s, "ui", 490, 1, 656, 167);
        };

        SpriteFactory.createSelectFrameS = function (s) {
          return SpriteFactory.createSpriteCore(s, "ui", 657, 1, 787, 131);
        };

        SpriteFactory.createMaskL = function (s) {
          var uv = [{
            left: 87,
            top: 571,
            right: 129,
            bottom: 613
          }, {
            left: 1,
            top: 571,
            right: 43,
            bottom: 613
          }, {
            left: 130,
            top: 571,
            right: 172,
            bottom: 613
          }, {
            left: 44,
            top: 571,
            right: 86,
            bottom: 613
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createMaskM = function (s) {
          var uv = [{
            left: 1,
            top: 542,
            right: 29,
            bottom: 570
          }, {
            left: 30,
            top: 542,
            right: 58,
            bottom: 570
          }, {
            left: 88,
            top: 542,
            right: 116,
            bottom: 570
          }, {
            left: 59,
            top: 542,
            right: 87,
            bottom: 570
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createMaskS = function (s) {
          var uv = [{
            left: 23,
            top: 520,
            right: 44,
            bottom: 541
          }, {
            left: 1,
            top: 520,
            right: 22,
            bottom: 541
          }, {
            left: 67,
            top: 520,
            right: 88,
            bottom: 541
          }, {
            left: 45,
            top: 520,
            right: 66,
            bottom: 541
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createGuideL = function (s) {
          var uv = [{
            left: 621,
            top: 330,
            right: 747,
            bottom: 415
          }, {
            left: 322,
            top: 289,
            right: 407,
            bottom: 415
          }, {
            left: 494,
            top: 330,
            right: 620,
            bottom: 415
          }, {
            left: 408,
            top: 289,
            right: 493,
            bottom: 415
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createGuideM = function (s) {
          var uv = [{
            left: 523,
            top: 416,
            right: 607,
            bottom: 473
          }, {
            left: 322,
            top: 416,
            right: 379,
            bottom: 500
          }, {
            left: 438,
            top: 416,
            right: 522,
            bottom: 473
          }, {
            left: 380,
            top: 416,
            right: 437,
            bottom: 500
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createGuideS = function (s) {
          var uv = [{
            left: 501,
            top: 501,
            right: 564,
            bottom: 544
          }, {
            left: 349,
            top: 501,
            right: 392,
            bottom: 564
          }, {
            left: 437,
            top: 501,
            right: 500,
            bottom: 544
          }, {
            left: 393,
            top: 501,
            right: 436,
            bottom: 564
          }];
          var sprT = [];
          uv.forEach(function (x) {
            sprT.push(SpriteFactory.createSpriteCore(s, "ui", x.left, x.top, x.right, x.bottom));
          });
          return sprT;
        };

        SpriteFactory.createAnimationSprite = function (_scene, srow, scolumn, row, column, show) {
          if (show === void 0) {
            show = true;
          }

          var spriteTable = [];
          var sw = 76;
          var sh = 78;
          var bx = 1 + srow * sw;
          var by = 538 + scolumn * sh + 1;
          var spr = null;

          for (var y = 0, ymax = column; y < ymax; ++y) {
            for (var x = 0, xmax = row; x < xmax; ++x) {
              var nbx = bx + x * sw + x;
              var nby = by + y * sh + y;
              spr = SpriteFactory.createSpriteCore(_scene, "ui", nbx, nby, nbx + sw, nby + sh);

              if (!show) {
                spr.hide();
              }

              spriteTable.push(spr);
            }
          }

          return spriteTable;
        };

        SpriteFactory.createRestNUMFrame = function (_s) {
          return SpriteFactory.createSprite(_s, 784, 1, 944, 47);
        };

        SpriteFactory.createSCOREFrame = function (_s) {
          return SpriteFactory.createSprite(_s, 1, 188, 446, 356);
        };

        SpriteFactory.createClockIcon = function (_s) {
          return SpriteFactory.createSprite(_s, 1, 524, 37, 560);
        };

        SpriteFactory.createPtImage = function (_s) {
          return SpriteFactory.createSprite(_s, 38, 524, 66, 552);
        };

        SpriteFactory.createComboRedBase = function (_s) {
          return SpriteFactory.createSprite(_s, 67, 524, 173, 554);
        };

        SpriteFactory.createComboYellowBase = function (_s) {
          return SpriteFactory.createSprite(_s, 174, 524, 297, 562);
        };

        SpriteFactory.createReady = function (_s) {
          return SpriteFactory.createSprite(_s, 447, 188, 691, 284);
        };

        SpriteFactory.createStart = function (_s) {
          return SpriteFactory.createSprite(_s, 447, 285, 733, 364);
        };

        SpriteFactory.createGameOver = function (_s) {
          return SpriteFactory.createSprite(_s, 1, 444, 426, 523);
        };

        SpriteFactory.createTimeUp = function (_s) {
          return SpriteFactory.createSprite(_s, 478, 444, 826, 539);
        };

        SpriteFactory.createSprite = function (_scene, sx, sy, ex, ey) {
          return this.createSpriteCore(_scene, "ui_common", sx, sy, ex, ey);
        };

        SpriteFactory.createSpriteCore = function (_s, name, sx, sy, ex, ey) {
          var sw = ex - sx;
          var sh = ey - sy;

          var imageAsset = _s.asset.getImageById(name);

          return new g.Sprite({
            scene: _s,
            src: imageAsset,
            anchorX: null,
            anchorY: null,
            srcX: sx,
            srcY: sy,
            srcWidth: sw,
            srcHeight: sh,
            width: sw,
            height: sh
          });
        };

        return SpriteFactory;
      }();

      exports.SpriteFactory = SpriteFactory;
    }, {}],
    20: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TimeOver = void 0;

      var SpriteFactory_1 = require("./SpriteFactory");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var AudioPresenter_1 = require("./AudioPresenter");

      var TimeOver =
      /** @class */
      function () {
        function TimeOver(_s) {
          this.finishCallback = new Array();
          this._s = _s;
          this.rootEntity = new g.E({
            scene: _s
          });

          var _t = SpriteFactory_1.SpriteFactory.createTimeUp(_s);

          _t.x = (_s.game.width - _t.width) / 2;
          _t.y = (_s.game.height - _t.height) / 2;

          _t.modified();

          _t.hide();

          this.timeUp = _t;
          this.rootEntity.append(_t);
        }

        TimeOver.prototype.show = function (intime, wait) {
          var _this = this;

          var tt = new akashic_timeline_1.Timeline(this._s);
          AudioPresenter_1.AudioPresenter.instance.playSE("finish");
          var _tu = this.timeUp;

          _tu.scale(1.5);

          _tu.opacity = 0;

          _tu.modified();

          _tu.show();

          tt.create(this.timeUp, {
            modified: this.timeUp.modified,
            destroyed: this.timeUp.destroyed
          }).scaleTo(1, 1, intime).con().fadeIn(intime).wait(wait).every(function (e, p) {
            if (1 <= p) {
              tt.destroy();

              _this.finishCallback.forEach(function (c) {
                return c();
              });

              _tu.hide();
            }
          }, intime + wait);
          return this;
        };

        return TimeOver;
      }();

      exports.TimeOver = TimeOver;
    }, {
      "./AudioPresenter": 7,
      "./SpriteFactory": 19,
      "@akashic-extension/akashic-timeline": 5
    }],
    21: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TitleScene = void 0;

      var AudioPresenter_1 = require("./AudioPresenter");

      var AStage_1 = require("./AStage");

      var TitleScene =
      /** @class */
      function (_super) {
        __extends(TitleScene, _super);

        function TitleScene(scene) {
          var _this = _super.call(this) || this;

          _this.scene = scene;
          return _this;
        }

        TitleScene.prototype.activate = function (_s) {
          var _this = this;

          var titleImageAsset = _s.asset.getImageById("title_mitta");

          var width = 480;
          var height = width * titleImageAsset.height / titleImageAsset.width;
          var title = new g.Sprite({
            scene: _s,
            src: titleImageAsset,
            width: width,
            height: height,
            srcWidth: titleImageAsset.width,
            srcHeight: titleImageAsset.height,
            x: (g.game.width - width) / 2,
            y: (g.game.height - height) / 2
          });
          this.title = title;
          AudioPresenter_1.AudioPresenter.instance.playRandomBGM();

          _s.onPointDownCapture.add(function () {
            _s.onPointDownCapture.removeAll();

            AudioPresenter_1.AudioPresenter.instance.playSE("se_002c");

            _s.setTimeout(function () {
              // 次のシーンへ行く
              _this.finishStage();
            }, 1000);
          });

          _s.append(title);

          this.scene = _s;
        };

        TitleScene.prototype.dispose = function () {
          if (!this.title.destroyed()) {
            this.title.destroy();
          }
        };

        return TitleScene;
      }(AStage_1.AStage);

      exports.TitleScene = TitleScene;
    }, {
      "./AStage": 6,
      "./AudioPresenter": 7
    }],
    22: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Util = void 0;

      var Global_1 = require("./Global");

      var Util =
      /** @class */
      function () {
        function Util() {}

        Util.shuffle = function (array) {
          var length = array == null ? 0 : array.length;

          if (!length) {
            return [];
          }

          if (length === 1) {
            return array.slice(0);
          }

          var index = -1;
          var lastIndex = length - 1;
          var result = [];
          result = array.slice(0);

          while (++index < length) {
            var rand = index + (Global_1.Global.instance.random.get(0, lastIndex - index) | 0);
            var value = result[rand];
            result[rand] = result[index];
            result[index] = value;
          }

          return result;
        };

        Util.readJSON = function (_s, name) {
          return JSON.parse(_s.asset.getTextById(name).data);
        };

        Util.lerp = function (a, b, t, matchThreshold) {
          if (matchThreshold === void 0) {
            matchThreshold = 0;
          }

          var r = (1 - t) * a + t * b;

          if (0 < matchThreshold) {
            if (Math.abs(r - a) < matchThreshold) {
              r = b;
            }
          }

          return r;
        };

        Util.range = function (start, count, step) {
          if (step === void 0) {
            step = 1;
          }

          var result = [];

          for (var i = 0; i < count; i++) {
            result.push(start + i * step);
          }

          return result;
        };

        Util.repeat = function (obj, count) {
          var result = [];

          for (var i = 0; i < count; i++) {
            result.push(obj);
          }

          return result;
        };

        return Util;
      }();

      exports.Util = Util;
    }, {
      "./Global": 13
    }],
    23: [function (require, module, exports) {
      "use strict";
      /**
       * ゲーム定数
       */

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.STUCK_DURATION = exports.FISHING_WAIT_DURATION = exports.FISHING_DURATION = exports.TIME_LABEL_FORMAT = exports.SCORE_LABEL_FORMAT = exports.HOOKS_LIMIT = exports.HOOKS_LEVELS = exports.HOOKS_INTERVAL = exports.HOOK_POS = exports.HOOK_BOLD = exports.HOOK_SIZE = exports.HOOK_COLOR = exports.ROD_STRING_HEIGHT_WHEN_UP = exports.ROD_STRING_POS = exports.ROD_STRING_SIZE = exports.ROD_STRING_COLOR = exports.ROD_ANGLE = exports.ROD_POS = exports.ROD_SIZE = exports.ROD_COLOR = exports.SWIMMING_TIME_RANGE = exports.FISH_INTERVAL = exports.FISH_FONT_SIZE = exports.BEAR_POS = exports.BEAR_SIZE = exports.BEAR_COLOR = exports.WATERSURFACE_COLOR = exports.WATERSURFACE_POS = exports.GRASS_POS = exports.GRASS_SIZE = exports.GRASS_COLOR = exports.ISLAND_POS = exports.ISLAND_SIZE = exports.ISLAND_COLOR = exports.BACKGROUND_ALPHA = exports.BACKGROUND_COLOR = exports.FONT_FAMILY = exports.FONT_SIZE = exports.TIMELIMIT = void 0;
      /**
       * 制限時間(セッションパラメータで制限時間が指定されたらその値を使用します)
       */

      exports.TIMELIMIT = 30;
      /**
       * フォントサイズ
       */

      exports.FONT_SIZE = 36;
      /**
       * フォントファミリー
       */

      exports.FONT_FAMILY = "sans-serif";
      /**
       * 背景の色
       */

      exports.BACKGROUND_COLOR = "#3fa7ff";
      /**
       * 背景の透過度
       */

      exports.BACKGROUND_ALPHA = 0.8;
      /**
       * 島の色
       */

      exports.ISLAND_COLOR = "#ffeca8";
      /**
       * 島の大きさ
       */

      exports.ISLAND_SIZE = {
        width: 200,
        height: 80
      };
      /**
       * 島の座標
       */

      exports.ISLAND_POS = {
        x: 0,
        y: g.game.height * 0.5 - exports.ISLAND_SIZE.height
      };
      /**
       * 草の色
       */

      exports.GRASS_COLOR = "#549637";
      /**
       * 草の大きさ
       */

      exports.GRASS_SIZE = {
        width: exports.ISLAND_SIZE.width - 40,
        height: exports.ISLAND_SIZE.height / 2
      };
      /**
       * 草の座標
       */

      exports.GRASS_POS = {
        x: 0,
        y: exports.ISLAND_POS.y - 20
      };
      /**
       * 水面の高さ
       */

      exports.WATERSURFACE_POS = {
        x: 0,
        y: g.game.height * 0.4
      };
      /**
       * 水面の色
       */

      exports.WATERSURFACE_COLOR = "#252525";
      /**
       * くまの色
       */

      exports.BEAR_COLOR = "white";
      /**
       * くまの大きさ
       */

      exports.BEAR_SIZE = {
        width: 50,
        height: 65
      };
      /**
       * くまの座標
       */

      exports.BEAR_POS = {
        x: 100,
        y: exports.GRASS_POS.y - exports.BEAR_SIZE.height / 2
      };
      /**
       * 魚のサイズ（横幅は魚の名前の長さに依存
       */

      exports.FISH_FONT_SIZE = 36;
      /**
       * 魚の生成間隔[ミリ秒]
       */

      exports.FISH_INTERVAL = 1000;
      /**
       * 魚が泳ぐ時間範囲[ミリ秒]
       */

      exports.SWIMMING_TIME_RANGE = {
        "very_fast": {
          min: 500,
          max: 1000
        },
        "fast": {
          min: 2000,
          max: 4000
        },
        "normal": {
          min: 5000,
          max: 7000
        },
        "slow": {
          min: 8000,
          max: 10000
        },
        "very_slow": {
          min: 12000,
          max: 15000
        }
      };
      /**
       * 釣り竿の色
       */

      exports.ROD_COLOR = "#835031";
      /**
       * 釣り竿の大きさ
       */

      exports.ROD_SIZE = {
        width: 3,
        height: 100
      };
      /**
       * 釣り竿の座標
       */

      exports.ROD_POS = {
        x: 155,
        y: 50
      };
      /**
       * 釣り竿の角度
       */

      exports.ROD_ANGLE = 30;
      /**
       * 釣り糸の色
       */

      exports.ROD_STRING_COLOR = "#252525";
      /**
       * 釣り糸の大きさ
       */

      exports.ROD_STRING_SIZE = {
        width: 3,
        height: 280
      };
      /**
       * 釣り糸の座標
       */

      exports.ROD_STRING_POS = {
        x: 180,
        y: exports.ROD_POS.y + 8
      };
      /**
       * 釣り上げ時の釣り糸の長さ
       */

      exports.ROD_STRING_HEIGHT_WHEN_UP = exports.ROD_STRING_SIZE.height / 5;
      /**
       * 釣り針の色
       */

      exports.HOOK_COLOR = "#525252";
      /**
       * 釣り針の大きさ
       */

      exports.HOOK_SIZE = {
        width: 32,
        height: 16
      };
      /**
       * 釣り針の太さ
       */

      exports.HOOK_BOLD = 5;
      /**
       * 釣り針の座標
       */

      exports.HOOK_POS = {
        x: exports.ROD_STRING_POS.x + exports.ROD_STRING_SIZE.width - exports.HOOK_SIZE.width,
        y: exports.ROD_STRING_POS.y + exports.ROD_STRING_SIZE.height - exports.HOOK_SIZE.height
      };
      /**
       * 釣り針間の間隔
       */

      exports.HOOKS_INTERVAL = exports.HOOK_SIZE.height;
      /**
       * 釣り針増やすためのスコア
       */

      exports.HOOKS_LEVELS = [0, 200, 1000, 2500, 10000];
      /**
       * 釣り針の数上限
       */

      exports.HOOKS_LIMIT = 5;
      /**
       * スコアラベルフォーマット
       */

      exports.SCORE_LABEL_FORMAT = "SCORE:";
      /**
       * 制限時間ラベルのフォーマット
       */

      exports.TIME_LABEL_FORMAT = "TIME:";
      /**
       * 釣りに要する時間[ミリ秒]
       */

      exports.FISHING_DURATION = 500;
      /**
       * 釣り待機時間[ミリ秒]
       */

      exports.FISHING_WAIT_DURATION = 300;
      /**
       * スタック時間[ミリ秒]
       */

      exports.STUCK_DURATION = 2000;
    }, {}],
    24: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Fish = void 0;

      var constants_1 = require("../constants");

      var Resources_1 = require("../Resources");
      /**
       * 魚クラス
       */


      var Fish =
      /** @class */
      function () {
        function Fish(param) {
          /**
           * 泳ぐアニメーション用の Tween
           */
          this._swimTween = null;
          this._parent = param.parent;
          this._sprite = this._createSprite(param);

          this._parent.append(this._sprite);

          this._isCaptured = false;
          this._score = param.score;
          this._swimmingStyle = param.swimmingStyle;
          this._name = param.name;
          this._direction = param.direction;
          this._shake = param.shake;
          this._isInseki = param.isInseki;
          this._isGameOver = param.isGameOver;
          this._se = param.se;
          this._time = param.time;
        }

        Object.defineProperty(Fish.prototype, "isCaptured", {
          get: function get() {
            return this._isCaptured;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "name", {
          get: function get() {
            return this._name;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "score", {
          get: function get() {
            return this._score;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "isGameOver", {
          get: function get() {
            return this._isGameOver;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "se", {
          get: function get() {
            return this._se;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "time", {
          get: function get() {
            return this._time;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Fish.prototype, "area", {
          /**
           * 魚の当たり判定を返す
           */
          get: function get() {
            return {
              width: this._sprite.width,
              height: this._sprite.height,
              x: this._sprite.x,
              y: this._sprite.y
            };
          },
          enumerable: false,
          configurable: true
        });

        Fish.prototype.destroy = function () {
          this._sprite.destroy();
        };
        /**
         * 釣られる
         */


        Fish.prototype.followHook = function (fishingRod, index) {
          var _this = this; // 魚の向きを回転


          this._sprite.anchorX = 0.5;
          this._sprite.anchorY = 0.5;

          if (this._direction == "right") {
            this._sprite.angle = 80;
          }

          if (this._direction == "left") {
            this._sprite.angle = -80;
          }

          if (this._sprite.scaleX >= 0) {
            this._sprite.angle *= -1;
          }

          this._sprite.modified(); // 釣られる場所まで移動


          this._sprite.onUpdate.add(function () {
            var hooksArea = fishingRod.hooksArea;
            _this._sprite.x = index % 2 === 0 ? hooksArea[index].x : hooksArea[index].x + constants_1.HOOK_SIZE.width;
            _this._sprite.y = Math.min(hooksArea[index].y, _this._sprite.y);

            _this._sprite.modified();
          });
        };
        /**
         * 泳ぐ
         */


        Fish.prototype.swim = function () {
          var _this = this;

          var timeline = Resources_1.getResources().timeline;
          var toX = this._sprite.x < g.game.width / 2 ? g.game.width : -this._sprite.width;
          var toY = this._sprite.y;

          if (this._swimTween) {
            timeline.remove(this._swimTween);
          }

          if (this._isInseki) {
            this._sprite.scaleX = -1;
            this._sprite.x = g.game.width;
            this._sprite.y = Math.floor(Math.random() * 300) - 300;
            toX = Math.floor(Math.random() * 300) - 250;
            toY = g.game.height;
          }

          this._swimTween = timeline.create(this._sprite).moveTo(toX, toY, this._swimmingStyle.swimTime).call(function () {
            return _this._sprite.destroy();
          }); // 揺れ

          if (this._shake == "fast") {
            timeline.create(this._sprite, {
              loop: true
            }).rotateBy(10, 100).rotateBy(-10, 100);
          }

          if (this._shake == "slow") {
            timeline.create(this._sprite, {
              loop: true
            }).rotateBy(20, 1000).rotateBy(-20, 1000);
          }
        };
        /**
         * 泳ぎをやめる
         */


        Fish.prototype.stop = function () {
          this._isCaptured = true;

          if (this._swimTween) {
            Resources_1.getResources().timeline.remove(this._swimTween);
            this._swimTween = null;
          }
        };
        /**
         * 魚作成
         */


        Fish.prototype._createSprite = function (param) {
          var scaleX = 1;

          if (param.direction == "left") {
            scaleX *= -1;
          }

          if (param.swimmingStyle.pattern == "right_to_left") {
            scaleX *= -1;
          }

          if (param.direction == "front") {
            scaleX = 1;
          }

          var asset = param.parent.scene.asset.getImageById(param.resourceName);
          return new g.Sprite(__assign({
            scene: param.parent.scene,
            src: asset,
            anchorX: null,
            anchorY: null,
            width: param.width,
            height: param.height ? param.height : param.width * asset.height / asset.width,
            srcWidth: asset.width,
            srcHeight: asset.height,
            scaleX: scaleX
          }, this._initialPos(param)));
        };
        /**
         * 初期位置生成
         */


        Fish.prototype._initialPos = function (param) {
          switch (param.swimmingStyle.pattern) {
            case "left_to_right":
              return {
                x: -constants_1.FISH_FONT_SIZE,
                y: param.swimmingStyle.depth
              };

            case "right_to_left":
              return {
                x: g.game.width,
                y: param.swimmingStyle.depth
              };
          }
        };

        return Fish;
      }();

      exports.Fish = Fish;
    }, {
      "../Resources": 17,
      "../constants": 23
    }],
    25: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FishingRod = void 0;

      var constants_1 = require("../constants");

      var Resources_1 = require("../Resources");
      /**
       * 釣り竿クラス
       */


      var FishingRod =
      /** @class */
      function () {
        function FishingRod(param) {
          /**
           * スタック時のトリガー
           */
          this.onStuck = new g.Trigger();
          this._parent = param.parent;
          this._isCatching = false;
          this._isFishing = false;

          this._createRod();

          this._createRodString();

          this._hooks = [];

          var firstHook = this._createHook(0);

          this._parent.append(firstHook);

          this._hooks.push(firstHook);
        }

        Object.defineProperty(FishingRod.prototype, "isCatching", {
          get: function get() {
            return this._isCatching;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(FishingRod.prototype, "hooksArea", {
          get: function get() {
            return this._hooks.map(function (hook) {
              return {
                width: hook.width,
                height: hook.height,
                x: hook.x,
                y: hook.y
              };
            });
          },
          enumerable: false,
          configurable: true
        });
        /**
         * 釣り上げる
         */

        FishingRod.prototype.catchUp = function (finished) {
          var _this = this;

          if (this._isFishing || this._isCatching) return;
          this._isCatching = true;
          this._isFishing = true;
          var timeline = Resources_1.getResources().timeline;
          timeline.create(this._rodString).to({
            height: constants_1.ROD_STRING_HEIGHT_WHEN_UP
          }, constants_1.FISHING_DURATION).wait(constants_1.FISHING_WAIT_DURATION);
          var isFinished = false;

          for (var i = 0; i < this._hooks.length; i++) {
            var hook = this._hooks[i];

            var pos = this._calcHookPositionWhenUp(i);

            timeline.create(hook).moveTo(pos.x, pos.y, constants_1.FISHING_DURATION).wait(constants_1.FISHING_WAIT_DURATION).call(function () {
              if (isFinished) return;
              isFinished = true;
              _this._isCatching = false;
              finished();
            });
          }
        };
        /**
         * 釣った魚からパターンを判定
         */


        FishingRod.prototype.getFishingPattern = function (capturedFishList) {
          var pattern = "Default";
          capturedFishList.forEach(function (fish) {
            if (pattern !== "Default") return;

            switch (fish.name) {
              case "くらげ":
                pattern = "Stuck";
                break;
            }
          });
          return pattern;
        };
        /**
         * パターンに従って釣りをする
         */


        FishingRod.prototype.fishing = function (pattern) {
          switch (pattern) {
            case "Default":
              this._swingDown();

              break;

            case "Stuck":
              this._stuck();

              break;
          }
        };
        /**
         * スコアに合わせて針の数を増減させる
         */


        FishingRod.prototype.addHooks = function () {
          var currentCount = this._hooks.length;
          var nextCount = currentCount + 1;

          if (nextCount > currentCount) {
            for (var i = currentCount; i < nextCount; i++) {
              var hook = this._createHook(i);

              this._hooks.push(hook);

              var pos = this._calcHookPositionWhenUp(i);

              hook.y = pos.y;

              this._parent.insertBefore(hook, this._hooks[i - 1]);
            }
          } else {
            for (var i = currentCount - 1; i >= nextCount; i--) {
              var hook = this._hooks.pop();

              this._parent.scene.remove(hook);
            }
          }
        }; // 釣り上げ時の釣り針の位置を計算


        FishingRod.prototype._calcHookPositionWhenUp = function (index) {
          return {
            x: this._hooks[index] !== undefined ? this._hooks[index].x : 0,
            // 5で割っているのは適当。最大5本針でも自然に映ればそれでOK。あとなぜか若干糸と離れてしまっているため-3するという謎処理もしてしまっている。。
            y: constants_1.ROD_POS.y + constants_1.ROD_STRING_HEIGHT_WHEN_UP - Math.round(index * (constants_1.HOOKS_INTERVAL / 5)) - 3
          };
        };
        /**
         * 振り下ろす
         */


        FishingRod.prototype._swingDown = function () {
          var _this = this;

          var timeline = Resources_1.getResources().timeline;
          timeline.create(this._rodString).to({
            height: constants_1.ROD_STRING_SIZE.height
          }, constants_1.FISHING_DURATION);

          for (var i = 0; i < this._hooks.length; i++) {
            var hook = this._hooks[i];
            timeline.create(hook).moveTo(hook.x, constants_1.HOOK_POS.y - constants_1.HOOKS_INTERVAL * i, constants_1.FISHING_DURATION).call(function () {
              _this._isFishing = false;
            });
          }
        };
        /**
         * スタックさせる
         */


        FishingRod.prototype._stuck = function () {
          var _this = this;

          this.onStuck.fire(); // ${STUCK_DURATION} ミリ秒後に、スタックを解除し、釣竿を振り下ろす

          var timeline = Resources_1.getResources().timeline;
          timeline.create(this._rodString).wait(constants_1.STUCK_DURATION);
          var fnishWaiting = false;

          for (var _i = 0, _a = this._hooks; _i < _a.length; _i++) {
            var hook = _a[_i];
            timeline.create(hook).wait(constants_1.STUCK_DURATION).call(function () {
              if (fnishWaiting) return;
              fnishWaiting = true;

              _this._swingDown();
            });
          }
        };
        /**
         * 釣竿を作成する
         */


        FishingRod.prototype._createRod = function () {
          new g.FilledRect(__assign(__assign(__assign({
            scene: this._parent.scene,
            cssColor: constants_1.ROD_COLOR
          }, constants_1.ROD_SIZE), constants_1.ROD_POS), {
            anchorX: null,
            anchorY: null,
            angle: constants_1.ROD_ANGLE,
            parent: this._parent
          }));
        };
        /**
         * 釣り糸を作成する
         */


        FishingRod.prototype._createRodString = function () {
          this._rodString = new g.FilledRect(__assign(__assign(__assign({
            scene: this._parent.scene,
            cssColor: constants_1.ROD_STRING_COLOR
          }, constants_1.ROD_STRING_SIZE), constants_1.ROD_STRING_POS), {
            parent: this._parent
          }));
        };
        /**
         * 釣り針を作成する
         */


        FishingRod.prototype._createHook = function (index) {
          var scene = this._parent.scene;
          var hook = new g.E(__assign(__assign({
            scene: scene
          }, constants_1.HOOK_SIZE), {
            x: constants_1.HOOK_POS.x,
            y: constants_1.HOOK_POS.y - index * constants_1.HOOKS_INTERVAL
          }));
          var rect1 = new g.FilledRect({
            scene: scene,
            cssColor: constants_1.HOOK_COLOR,
            width: hook.width,
            height: constants_1.HOOK_BOLD,
            y: hook.height - constants_1.HOOK_BOLD,
            parent: hook
          });
          var rect2 = new g.FilledRect({
            scene: scene,
            cssColor: constants_1.HOOK_COLOR,
            width: constants_1.HOOK_BOLD,
            height: hook.height,
            parent: hook
          });

          if (index % 2 === 1) {
            hook.x += constants_1.HOOK_SIZE.width - constants_1.ROD_STRING_SIZE.width;
            rect2.x = hook.width - constants_1.HOOK_BOLD;
          }

          return hook;
        };

        return FishingRod;
      }();

      exports.FishingRod = FishingRod;
    }, {
      "../Resources": 17,
      "../constants": 23
    }],
    26: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Sea = void 0;

      var constants_1 = require("../constants");

      var Fish_1 = require("./Fish");

      var AudioPresenter_1 = require("./../AudioPresenter");
      /**
       * 出現する魚の種類
       */


      var fishInfoList = {
        "dragoncube01": {
          name: "ドラゴンキューブ01",
          width: 50,
          score: 1,
          direction: "front"
        },
        "dragoncube02": {
          name: "ドラゴンキューブ02",
          width: 50,
          score: 1,
          direction: "front"
        },
        "dragoncube03": {
          name: "ドラゴンキューブ03",
          width: 50,
          score: 1,
          direction: "front"
        },
        "fish_freelance": {
          name: "フリーランス",
          width: 100,
          score: 1000,
          direction: "left"
        },
        "fish_mixityan": {
          name: "みぃちゃんザウルス",
          width: 200,
          score: 50,
          speed: "very_slow"
        },
        "fish_ryouran": {
          name: "繚乱ちゃん",
          width: 50,
          score: 90000,
          speed: "very_fast",
          direction: "front"
        },
        "fish_takarabako": {
          name: "宝箱",
          width: 100,
          score: 0,
          direction: "left"
        },
        "fish_mint": {
          name: "ミント",
          width: 100,
          score: -1000,
          speed: "fast",
          direction: "left"
        },
        "fish_gadhirasu": {
          name: "ガディラス",
          width: 200,
          score: 10000,
          speed: "slow",
          direction: "front"
        },
        "fish_gonbirasu": {
          name: "ゴンビラス",
          width: 400,
          score: 99500,
          speed: "very_fast",
          direction: "front"
        },
        "fish_hurora": {
          name: "フローラ",
          width: 100,
          score: 10000,
          speed: "fast",
          direction: "left"
        },
        "fish_mixi": {
          name: "みぃちゃん",
          width: 100,
          score: -99999,
          direction: "left",
          shake: "fast",
          se: "mada"
        },
        "fish_madagasukaru": {
          name: "マダガスカル",
          width: 100,
          score: 1,
          speed: "fast",
          direction: "front"
        },
        "fish_wakusei": {
          name: "惑星",
          width: 100,
          score: 0,
          speed: "fast",
          direction: "front",
          time: -10
        }
      };
      var firstStageFishKeys = ["fish_freelance", "fish_mixityan", "fish_mixityan", "fish_takarabako", "fish_takarabako", "fish_mint", "fish_mint", "fish_mint", "dragoncube01", "dragoncube02", "dragoncube03", "fish_hurora", "fish_mixi", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_wakusei", "fish_wakusei"];
      var secondStageFishKeys = ["fish_freelance", "fish_mixityan", "fish_mixityan", "fish_takarabako", "fish_takarabako", "fish_ryouran", "fish_mint", "fish_mint", "fish_mint", "dragoncube01", "dragoncube02", "dragoncube03", "fish_mixi", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_wakusei", "fish_wakusei", "fish_gadhirasu", "fish_hurora"];
      var thirdStageFishKeys = ["fish_freelance", "fish_mixityan", "fish_mixityan", "fish_takarabako", "fish_takarabako", "fish_mint", "fish_mint", "fish_mint", "dragoncube01", "dragoncube02", "dragoncube03", "fish_mixi", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_madagasukaru", "fish_gadhirasu", "fish_gonbirasu", "fish_wakusei", "fish_wakusei"];
      /**
       * 海クラス
       */

      var Sea =
      /** @class */
      function () {
        function Sea(param) {
          this.capturedFishList = [];
          this._parent = param.parent;
          this._fishList = [];
        }
        /**
         * 残り時間を管理するタイマー(FieldSceneからもらう)
         */


        Sea.prototype.setTimer = function (timer) {
          this._timer = timer;
          this._maxTimeValue = timer.now;
        };
        /**
         * 定期的に魚を作成する
         */


        Sea.prototype.startFishTimer = function () {
          var _this = this;

          this._fishTimerIdentifier = this._parent.scene.setInterval(function () {
            var count = 2; // 出す魚の数

            for (var i = 1; i <= count; i++) {
              var fish = _this._createRandomFish(_this._parent);

              fish.swim();

              _this._fishList.push(fish);
            }
          }, constants_1.FISH_INTERVAL);
        };
        /**
         * タイマーをクリアする
         */


        Sea.prototype.clearFishTimer = function () {
          if (!this._fishTimerIdentifier) return;

          this._parent.scene.clearInterval(this._fishTimerIdentifier);

          this._fishTimerIdentifier = null;
        };
        /**
         * 釣り針と魚の当たり判定をチェックする
         */


        Sea.prototype.checkFishOnHook = function (fishingRod) {
          var _this = this;

          if (!this._fishList.length) return;
          if (!fishingRod.isCatching) return;

          this._fishList.forEach(function (fish) {
            // 釣り針と魚が当たっていた場合は釣り上げる
            var hooksArea = fishingRod.hooksArea;

            for (var i = 0; i < hooksArea.length; i++) {
              var area = hooksArea[i];

              if (g.Collision.intersectAreas(area, fish.area)) {
                if (fish.isCaptured) return;
                fish.stop();
                fish.followHook(fishingRod, i);
                _this._fishList = _this._fishList.filter(function (item) {
                  return item !== fish;
                });

                _this.capturedFishList.push(fish);
              }
            }
          });
        };

        ;
        /**
         * 捕まえた魚たちを destroy する
         */

        Sea.prototype.destroyCapturedFish = function () {
          this.capturedFishList.forEach(function (capturedFish) {
            if (capturedFish.se) {
              AudioPresenter_1.AudioPresenter.instance.playSE(capturedFish.se);
            }
          });
          this.capturedFishList.forEach(function (capturedFish) {
            return capturedFish.destroy();
          });
          this.capturedFishList = [];
        };
        /**
         * ランダムな魚を作成
         */


        Sea.prototype._createRandomFish = function (parent) {
          // 作成する魚の種類
          var fishKeys = this.getFishKeys();
          var fishIdx = Math.floor(g.game.random.generate() * fishKeys.length);
          var fishKey = fishKeys[fishIdx];
          var fishInfo = fishInfoList[fishKey]; // 魚の泳ぎ方のパターン

          var pattern = Math.round(g.game.random.generate()) ? "right_to_left" : "left_to_right"; // 魚が泳ぐ水深

          var asset = parent.scene.asset.getImageById(fishKey);
          var fishHeight = fishInfo.height ? fishInfo.height : fishInfo.width * asset.height / asset.width;
          var depth;

          if (fishInfo.depth == "deep") {
            // deepの場合は海底固定
            depth = g.game.height - fishHeight;
          } else {
            depth = constants_1.WATERSURFACE_POS.y + Math.floor(g.game.random.generate() * (g.game.height - constants_1.WATERSURFACE_POS.y - fishHeight + 1));
          } // 魚が泳ぐ速度(5段階)


          var speed = fishInfo.speed || "normal"; // 魚が泳ぐ時間

          var swimTime = Math.floor(g.game.random.generate() * (constants_1.SWIMMING_TIME_RANGE[speed].max + 1)) + constants_1.SWIMMING_TIME_RANGE[speed].min; // 魚の向き

          var direction = fishInfo.direction || "right"; // 隕石みたいに動くか

          var isInseki = fishInfo.isInseki || false; // 釣ったらゲームオーバーになるか

          var isGameOver = fishInfo.isGameOver || false;
          var time = fishInfo.time || 0;
          return new Fish_1.Fish({
            parent: parent,
            name: fishInfo.name,
            resourceName: fishKey,
            width: fishInfo.width,
            height: fishInfo.height,
            score: fishInfo.score,
            direction: direction,
            shake: fishInfo.shake,
            isInseki: isInseki,
            isGameOver: isGameOver,
            se: fishInfo.se,
            time: time,
            swimmingStyle: {
              pattern: pattern,
              depth: depth,
              swimTime: swimTime
            }
          });
        };
        /**
         * 現在のステージに合わせた魚のキー一覧を返します
         */


        Sea.prototype.getFishKeys = function () {
          var stage = this.calcStage();
          this._stage = stage;

          if (stage == "firstStage") {
            return firstStageFishKeys;
          }

          if (stage == "secondStage") {
            return secondStageFishKeys;
          }

          if (stage == "thirdStage") {
            return thirdStageFishKeys;
          }
        };
        /**
         * 現在の残り時間から今のステージを計算します
         * 現在は序盤(ファーストステージ)、中盤(セカンドステージ)、終盤（サードステージ）の3ステージ
         */


        Sea.prototype.calcStage = function () {
          if (this._timer.now >= Math.floor(this._maxTimeValue * 2 / 3)) {
            return "firstStage";
          }

          if (this._timer.now >= Math.floor(this._maxTimeValue * 1 / 3)) {
            return "secondStage";
          }

          return "thirdStage";
        };

        return Sea;
      }();

      exports.Sea = Sea;
    }, {
      "../constants": 23,
      "./../AudioPresenter": 7,
      "./Fish": 24
    }],
    27: [function (require, module, exports) {
      "use strict";

      var AudioPresenter_1 = require("./AudioPresenter");

      var FieldScene_1 = require("./FieldScene");

      var Global_1 = require("./Global");

      var NumberValue_1 = require("./NumberValue");

      var OuterParamReceiver_1 = require("./OuterParamReceiver");

      var ResultScene_1 = require("./ResultScene");

      var TitleScene_1 = require("./TitleScene");

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          assetIds: getAssetIds()
        });
        Global_1.Global.init();
        Global_1.Global.instance.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined";
        OuterParamReceiver_1.OuterParamReceiver.receiveParamFromMessage(scene);
        OuterParamReceiver_1.OuterParamReceiver.paramSetting();
        scene.onLoad.add(function () {
          AudioPresenter_1.AudioPresenter.initialize(scene);
          NumberValue_1.NumberFont.instance.initialize(scene);
          var title = new TitleScene_1.TitleScene(scene);
          var field = new FieldScene_1.FieldScene(scene);
          var result = new ResultScene_1.ResultScene(scene);
          title.finishCallback.push(function () {
            title.dispose();
            field.activate(scene);
          });
          field.finishCallback.push(function () {
            field.dispose();
            result.activate(scene);
          });
          title.activate(scene);
        });
        g.game.pushScene(scene);
      }
      /**
       * ゲームが最初に読み込むべきアセットID一覧を返します
       */


      function getAssetIds() {
        var assetIds = [];
        var assets = g.game._configuration.assets;

        for (var _i = 0, _a = Object.keys(assets); _i < _a.length; _i++) {
          var assetId = _a[_i];

          if (assets[assetId].type == "image" || assets[assetId].type == "audio" || assets[assetId].type == "text") {
            assetIds.push(assetId.toString());
          }
        }

        return assetIds;
      }

      module.exports = main;
    }, {
      "./AudioPresenter": 7,
      "./FieldScene": 9,
      "./Global": 13,
      "./NumberValue": 14,
      "./OuterParamReceiver": 15,
      "./ResultScene": 18,
      "./TitleScene": 21
    }]
  }, {}, [27])(27);
});